<?php // tar-based phar archive stub file
__HALT_COMPILER();